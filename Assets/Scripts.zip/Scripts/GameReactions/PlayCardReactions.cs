﻿using System.Linq;
using UnityEngine;

public class PlayCardReactions : MonoBehaviour
{
	[SerializeField] private HealthDisplay playerHealth;
	[SerializeField] private HealthDisplay opponentHealth;
	[SerializeField] private TurnSystem turnSystem;

	private void OnEnable()
	{
		ActionSystem.SubscribeReaction<PlayCardGA>(PlayCardReactionPOST, ReactionTiming.POST);
	}

	private void OnDisable()
	{
		ActionSystem.UnsubscribeReaction<PlayCardGA>(PlayCardReactionPOST, ReactionTiming.POST);
	}

	private void PlayCardReactionPOST(PlayCardGA action)
	{
		Debug.Log("Verificando vezes que essa reaction é chamada");
		if (action.Card == null)
			return;

		CardDisplay cardDisplay = action.Card;
		bool isPlayerCard = cardDisplay.OwnerCard.isPlayerCard;

		if (action.IsValueSlot)
		{
			int value = int.Parse(cardDisplay.cardTopValue.text);
		}

		ActionSystem.Instance.AddReaction(new AdvanceTurnGA());
	}
}
