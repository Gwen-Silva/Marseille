/// <summary>
/// Represents a GameAction that initializes and generates decks for the game.
/// </summary>
public class GenerateDecksGA : GameAction { }
