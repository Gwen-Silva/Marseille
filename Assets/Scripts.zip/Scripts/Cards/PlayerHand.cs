public class PlayerHand : HorizontalCardHolder
{
	protected override void Start()
	{
		base.Start();
	}
}
