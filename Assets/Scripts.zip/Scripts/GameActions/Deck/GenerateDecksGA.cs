public class GenerateDecksGA : GameAction
{

}
