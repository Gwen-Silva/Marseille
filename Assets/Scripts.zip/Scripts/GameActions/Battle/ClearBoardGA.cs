public class ClearBoardGA : GameAction
{
}
