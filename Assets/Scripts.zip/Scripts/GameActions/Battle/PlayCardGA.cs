using UnityEngine;

public class PlayCardGA : GameAction
{
	public CardDisplay Card;
	public CardDropZone TargetSlot;
	public bool IsValueSlot;

	public PlayCardGA() { }
}