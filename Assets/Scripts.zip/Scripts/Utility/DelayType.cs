public enum DelayType
{
	VeryShort,
	Short,
	Medium,
	Long,
	VeryLong
}