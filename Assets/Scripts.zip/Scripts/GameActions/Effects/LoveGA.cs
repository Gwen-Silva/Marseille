using UnityEngine;

public class LoveGA : GameAction
{
	public Card Card;

	public LoveGA(Card card)
	{
		Card = card;
	}
}
