/// <summary>
/// Represents a GameAction that resolves a round, triggering effects and calculating damage based on card values.
/// </summary>
public class ResolveRoundGA : GameAction { }
