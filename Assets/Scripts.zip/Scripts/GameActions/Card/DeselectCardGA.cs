public class DeselectCardGA : GameAction
{
	public Card card;

	public DeselectCardGA(Card card)
	{
		this.card = card;
	}
}