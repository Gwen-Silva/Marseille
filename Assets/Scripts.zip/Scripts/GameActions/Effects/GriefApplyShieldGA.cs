using UnityEngine;

public class GriefApplyShieldGA : GameAction
{
	public Card Card;

	public GriefApplyShieldGA(Card card)
	{
		Card = card;
	}
}
