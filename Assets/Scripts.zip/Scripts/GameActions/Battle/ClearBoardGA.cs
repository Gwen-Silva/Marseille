/// <summary>
/// Represents a GameAction that clears all cards from the board slots at the end of a round.
/// </summary>
public class ClearBoardGA : GameAction { }
