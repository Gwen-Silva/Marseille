public class SelectCardGA : GameAction
{
	public Card card;

	public SelectCardGA(Card card)
	{
		this.card = card;
	}
}
