using UnityEngine;

public class GriefGA : GameAction
{
	public Card Card;

	public GriefGA(Card card)
	{
		Card = card;
	}
}
