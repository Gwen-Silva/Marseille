public class DoubtGA : GameAction
{
	public Card Card;

	public DoubtGA(Card card)
	{
		Card = card;
	}
}
