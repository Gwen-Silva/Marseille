public enum ReactionTiming
{
	PRE,
	POST
}
