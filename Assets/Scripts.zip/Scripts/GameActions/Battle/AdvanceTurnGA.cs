/// <summary>
/// Represents a GameAction that advances the turn to the next active slot in the turn order.
/// </summary>
public class AdvanceTurnGA : GameAction { }
