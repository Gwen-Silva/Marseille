public class ResolveRoundGA : GameAction
{

}
