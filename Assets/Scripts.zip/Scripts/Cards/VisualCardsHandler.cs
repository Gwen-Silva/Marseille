using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class VisualCardsHandler : MonoBehaviour
{

	public static VisualCardsHandler instance;

	private void Awake()
	{
		instance = this;
	}
	void Start()
	{

	}
	void Update()
	{

	}
}
