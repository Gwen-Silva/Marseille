public class StartGameGA : GameAction
{
	
}
