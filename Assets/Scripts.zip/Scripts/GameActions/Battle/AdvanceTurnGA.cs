public class AdvanceTurnGA : GameAction
{
	
}
