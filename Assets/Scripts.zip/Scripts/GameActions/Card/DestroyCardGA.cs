public class DestroyCardGA : GameAction
{
	public Card card;

	public DestroyCardGA(Card card)
	{
		this.card = card;
	}
}
